const usuarios = [
  {
    id: 1,
    nombre: "Enrique",
    apellido: "Toledo",
    edad: 23,
    color: "Rojo",
  },
  {
    id: 2,
    nombre: "Esteban",
    apellido: "Quito",
    edad: 47,
    color: "Azul",
  },
  {
    id: 3,
    nombre: "Elton",
    apellido: "Tito",
    edad: 53,
    color: "Amarillo",
  },
];
export default usuarios;
